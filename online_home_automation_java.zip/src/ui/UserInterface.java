package ui;

import controllers.*;
import java.util.Scanner;

public class UserInterface {
    LightController light=new LightController();
    FanController fan=new FanController();
    SecurityController security=new SecurityController();
    SensorController sensor=new SensorController();
    Scanner sc=new Scanner(System.in);

    public void showMainMenu(){
        int choice;
        do{
            System.out.println("\n==== ONLINE HOME AUTOMATION SYSTEM ====");
            System.out.println("1. Control Lights");
            System.out.println("2. Control Fans");
            System.out.println("3. Security System");
            System.out.println("4. Sensors");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice=sc.nextInt();
            switch(choice){
                case 1: lightMenu(); break;
                case 2: fanMenu(); break;
                case 3: securityMenu(); break;
                case 4: sensorMenu(); break;
                case 5: System.out.println("Exiting..."); break;
                default: System.out.println("Invalid choice.");
            }
        }while(choice!=5);
    }

    private void lightMenu(){
        System.out.println("\n--- LIGHT CONTROL ---");
        System.out.println("1. Turn ON");
        System.out.println("2. Turn OFF");
        int c=sc.nextInt();
        if(c==1)light.turnOn();
        else if(c==2)light.turnOff();
        else System.out.println("Invalid.");
    }

    private void fanMenu(){
        System.out.println("\n--- FAN CONTROL ---");
        int speed=sc.nextInt();
        fan.setFanSpeed(speed);
    }

    private void securityMenu(){
        System.out.println("\n--- SECURITY SYSTEM ---");
        System.out.println("1. Enable");
        System.out.println("2. Disable");
        int c=sc.nextInt();
        if(c==1)security.enable();
        else if(c==2)security.disable();
        else System.out.println("Invalid.");
    }

    private void sensorMenu(){
        System.out.println("\n--- SENSOR DATA ---");
        sensor.showTemperature();
    }
}