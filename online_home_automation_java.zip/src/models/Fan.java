package models;

public class Fan {
    private int speed;
    public void setSpeed(int speed){this.speed=speed;}
    public int getSpeed(){return speed;}
}