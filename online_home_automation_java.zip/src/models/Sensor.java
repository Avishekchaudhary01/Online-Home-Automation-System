package models;

import java.util.Random;
public class Sensor {
    public int readTemperature(){return new Random().nextInt(40)+10;}
}