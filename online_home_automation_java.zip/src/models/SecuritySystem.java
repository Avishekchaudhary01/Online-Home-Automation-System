package models;

public class SecuritySystem {
    private boolean enabled;
    public void enable(){enabled=true;}
    public void disable(){enabled=false;}
    public boolean isEnabled(){return enabled;}
}