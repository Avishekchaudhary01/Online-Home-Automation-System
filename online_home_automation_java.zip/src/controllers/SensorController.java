package controllers;
import models.Sensor;

public class SensorController {
    Sensor sensor=new Sensor();
    public void showTemperature(){System.out.println("Current Temperature: "+sensor.readTemperature()+" °C");}
}