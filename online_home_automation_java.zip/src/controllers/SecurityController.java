package controllers;
import models.SecuritySystem;

public class SecurityController extends DeviceController {
    SecuritySystem sec=new SecuritySystem();
    public void enable(){sec.enable();logAction("Security","ENABLED");System.out.println("Security ENABLED.");}
    public void disable(){sec.disable();logAction("Security","DISABLED");System.out.println("Security DISABLED.");}
}