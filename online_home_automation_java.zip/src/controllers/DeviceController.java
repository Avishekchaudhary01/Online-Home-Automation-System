package controllers;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class DeviceController {
    public void logAction(String device,String action){
        try{
            FileWriter w=new FileWriter("logs/device_log.txt",true);
            w.write(LocalDateTime.now()+" - "+device+" : "+action+"\n");
            w.close();
        }catch(IOException e){System.out.println("Error writing log.");}
    }
}