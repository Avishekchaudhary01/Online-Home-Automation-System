package controllers;
import models.Light;

public class LightController extends DeviceController {
    Light light=new Light();
    public void turnOn(){light.turnOn();logAction("Light","ON");System.out.println("Lights turned ON.");}
    public void turnOff(){light.turnOff();logAction("Light","OFF");System.out.println("Lights turned OFF.");}
}