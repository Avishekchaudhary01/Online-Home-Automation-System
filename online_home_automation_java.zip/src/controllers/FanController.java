package controllers;
import models.Fan;

public class FanController extends DeviceController {
    Fan fan=new Fan();
    public void setFanSpeed(int speed){
        if(speed<0||speed>5){System.out.println("Invalid speed.");return;}
        if(speed==0){logAction("Fan","OFF");System.out.println("Fan turned OFF.");}
        else{fan.setSpeed(speed);logAction("Fan","Speed "+speed);System.out.println("Fan speed set to "+speed);}
    }
}